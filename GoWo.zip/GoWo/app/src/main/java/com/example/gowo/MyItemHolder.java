package com.example.gowo;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyItemHolder extends RecyclerView.ViewHolder {
    public MyItemHolder(@NonNull View itemView) {
        super(itemView);
    }
}
